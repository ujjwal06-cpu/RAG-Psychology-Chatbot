import io
import os
import re
import math
import time
import logging
from collections import Counter
from dataclasses import dataclass, field
from typing import List, Tuple, Dict

logger = logging.getLogger(__name__)


@dataclass
class Chunk:
    text: str
    doc_name: str
    tf: Dict[str, float] = field(default_factory=dict)


class RAGEngine:
    CHUNK_SIZE    = 300
    CHUNK_OVERLAP = 50
    TOP_K         = 5
    MAX_DOCS      = 5

    SYSTEM_PROMPT = (
        "You are a document Q&A assistant. "
        "Answer ONLY from the document excerpts given to you. "
        "If the answer is not present in the excerpts, respond with exactly: "
        "Sorry, I cannot answer that question as I do not have sufficient information in the uploaded documents. "
        "Never use outside knowledge. Never make up facts."
    )

    def __init__(self):
        self._chunks: List[Chunk] = []
        self._doc_index: Dict[str, List[int]] = {}
        self._idf: Dict[str, float] = {}
        self._model = None
        self._api_key = ""

    def set_api_key(self, key: str):
        self._api_key = key.strip()
        self._model = None

    def total_chunks(self) -> int:
        return len(self._chunks)

    def clear(self):
        self._chunks.clear()
        self._doc_index.clear()
        self._idf.clear()
        self._model = None

    def add_document(self, filename: str, pdf_bytes: bytes, progress_cb=None) -> Tuple[bool, str]:
        if filename in self._doc_index:
            return True, "Already indexed"
        if len(self._doc_index) >= self.MAX_DOCS:
            return False, "Max 5 documents allowed"

        def upd(pct: int, msg: str):
            if progress_cb:
                try:
                    progress_cb.progress(pct, text=msg)
                except Exception:
                    pass

        upd(10, "Extracting text from PDF...")
        text, err = self._extract(pdf_bytes)
        if err or not text.strip():
            return False, err or "No readable text found in PDF"

        upd(45, "Splitting into chunks...")
        chunks = self._make_chunks(text, filename)
        if not chunks:
            return False, "Could not create chunks from PDF"

        upd(75, f"Building search index ({len(chunks)} chunks)...")
        for chunk in chunks:
            words = self._tokenize(chunk.text)
            cnt   = Counter(words)
            total = max(len(words), 1)
            chunk.tf = {w: n / total for w, n in cnt.items()}

        start = len(self._chunks)
        self._chunks.extend(chunks)
        self._doc_index[filename] = list(range(start, start + len(chunks)))
        self._rebuild_idf()

        upd(100, f"Done! {len(chunks)} chunks indexed.")
        return True, f"Indexed {len(chunks)} chunks"

    def remove_document(self, filename: str):
        if filename not in self._doc_index:
            return
        remove_set = set(self._doc_index.pop(filename))
        self._chunks = [c for i, c in enumerate(self._chunks) if i not in remove_set]
        self._doc_index = {
            d: [i for i, c in enumerate(self._chunks) if c.doc_name == d]
            for d in self._doc_index
        }
        self._rebuild_idf()

    def query(self, question: str) -> Tuple[str, List[str]]:
        no_info = (
            "Sorry, I cannot answer that question as I do not have sufficient "
            "information in the uploaded documents."
        )
        if not self._chunks:
            return no_info, []

        chunks = self._retrieve(question)
        if not chunks:
            return no_info, []

        context = "\n\n---\n\n".join(
            f"[Source: {c.doc_name}]\n{c.text}" for c in chunks
        )

        try:
            answer = self._ask_gemini(question, context)
        except Exception as e:
            return f"Error calling Gemini API: {e}", []

        if "cannot answer" in answer.lower() or "sufficient information" in answer.lower():
            return answer, []

        sources = list(dict.fromkeys(c.doc_name for c in chunks))
        return answer, sources

    STOPWORDS = {
        "the","a","an","and","or","but","in","on","at","to","for","of","with",
        "is","are","was","were","be","have","has","had","do","does","did",
        "this","that","it","its","not","as","from","by","so","if","we","i",
        "you","he","she","they","what","which","who","how","when","where","will",
        "would","could","should","their","there","been","being","about","into",
    }

    def _tokenize(self, text: str) -> List[str]:
        return [
            w for w in re.findall(r"[a-z0-9]+", text.lower())
            if w not in self.STOPWORDS and len(w) > 2
        ]

    def _rebuild_idf(self):
        N = len(self._chunks)
        if not N:
            self._idf = {}
            return
        df: Dict[str, int] = {}
        for c in self._chunks:
            for t in c.tf:
                df[t] = df.get(t, 0) + 1
        self._idf = {t: math.log((N + 1) / (f + 1)) + 1 for t, f in df.items()}

    def _retrieve(self, question: str) -> List[Chunk]:
        words = self._tokenize(question)
        if not words:
            return []
        total = max(len(words), 1)
        qtf   = {w: c / total for w, c in Counter(words).items()}
        scored = []
        for chunk in self._chunks:
            score = sum(
                qtf[t] * chunk.tf.get(t, 0) * self._idf.get(t, 1) ** 2
                for t in qtf if t in chunk.tf
            )
            if score > 0:
                scored.append((score, chunk))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [c for _, c in scored[: self.TOP_K]]

    def _make_chunks(self, text: str, doc_name: str) -> List[Chunk]:
        text  = re.sub(r"\s+", " ", text).strip()
        words = text.split()
        chunks, i = [], 0
        while i < len(words):
            part = " ".join(words[i: i + self.CHUNK_SIZE])
            if len(part) > 80:
                chunks.append(Chunk(text=part, doc_name=doc_name))
            i += self.CHUNK_SIZE - self.CHUNK_OVERLAP
        return chunks

    def _extract(self, pdf_bytes: bytes) -> Tuple[str, str]:
        try:
            import fitz
            doc  = fitz.open(stream=pdf_bytes, filetype="pdf")
            text = "\n\n".join(page.get_text("text") for page in doc)
            doc.close()
            if text.strip():
                return text, ""
        except Exception as e:
            logger.warning("PyMuPDF: %s", e)

        try:
            import pdfplumber
            with pdfplumber.open(io.BytesIO(pdf_bytes)) as f:
                text = "\n\n".join(p.extract_text() or "" for p in f.pages)
            if text.strip():
                return text, ""
        except Exception as e:
            logger.warning("pdfplumber: %s", e)

        try:
            from pypdf import PdfReader
            r    = PdfReader(io.BytesIO(pdf_bytes))
            text = "\n\n".join(p.extract_text() or "" for p in r.pages)
            if text.strip():
                return text, ""
        except Exception as e:
            logger.warning("pypdf: %s", e)

        return "", "Cannot read this PDF. Make sure it has selectable text (not a scanned image)."

    def _ask_gemini(self, question: str, context: str) -> str:
        if not self._model:
            try:
                import google.generativeai as genai
            except ImportError:
                raise ImportError("Run: pip install google-generativeai")
            key = self._api_key or os.environ.get("GEMINI_API_KEY", "")
            if not key:
                raise ValueError("No Gemini API key — enter it in the sidebar.")
            genai.configure(api_key=key)
            self._model = genai.GenerativeModel(
                model_name="gemini-2.0-flash",
                system_instruction=self.SYSTEM_PROMPT,
            )

        prompt = f"Document excerpts:\n\n{context}\n\nQuestion: {question}"

        # Retry up to 3 times if rate limited
        for attempt in range(3):
            try:
                response = self._model.generate_content(prompt)
                return response.text
            except Exception as e:
                err = str(e).lower()
                if "429" in err or "quota" in err or "retry" in err or "resource" in err:
                    wait = (attempt + 1) * 25
                    logger.warning("Rate limited. Waiting %ds before retry %d...", wait, attempt + 1)
                    time.sleep(wait)
                else:
                    raise e

        return "Sorry, Gemini API is busy right now. Please wait a minute and try again."