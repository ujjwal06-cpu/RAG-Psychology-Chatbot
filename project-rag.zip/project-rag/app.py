import streamlit as st
import os
from rag_engine import RAGEngine

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="PDF Knowledge Base",
    page_icon="📄",
    layout="wide",
)

# ── CSS ────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .block-container { padding-top: 2rem; }
    .source-tag {
        display: inline-block;
        background: #e8f4fd;
        color: #1565c0;
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 0.78rem;
        margin: 2px;
    }
    div[data-testid="stChatMessage"] {
        border-radius: 10px;
        margin-bottom: 0.5rem;
    }
</style>
""", unsafe_allow_html=True)

# ── Session state ──────────────────────────────────────────────────────────────
if "rag"             not in st.session_state: st.session_state.rag = RAGEngine()
if "chat_history"    not in st.session_state: st.session_state.chat_history = []
if "processed_files" not in st.session_state: st.session_state.processed_files = {}

rag: RAGEngine = st.session_state.rag

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 📂 Document Manager")
    st.divider()

    # API key input
    api_key = st.text_input(
        "🔑 Gemini API Key",
        type="password",
        placeholder="AIzaSy...",
        help="Free key from aistudio.google.com — never stored on disk",
    )
    if api_key:
        rag.set_api_key(api_key)
        st.success("✅ API key saved!")

    st.markdown("### Upload PDFs")
    uploaded = st.file_uploader(
        "label",
        type=["pdf"],
        accept_multiple_files=True,
        label_visibility="collapsed",
    )
    st.caption("Up to 5 PDFs · max 20 MB each")

    # ── Process newly uploaded files ───────────────────────────────────────────
    if uploaded:
        new_files = [
            f for f in uploaded
            if f.name not in st.session_state.processed_files
        ]

        slots_left = 5 - len(st.session_state.processed_files)
        if len(new_files) > slots_left:
            st.warning(f"Only {slots_left} slot(s) left. Extra files ignored.")
            new_files = new_files[:slots_left]

        for uf in new_files:
            if uf.size > 20 * 1024 * 1024:
                st.error(f"❌ {uf.name} is over 20 MB — skipped.")
                st.session_state.processed_files[uf.name] = "error"
                continue

            bar = st.progress(0, text=f"Starting {uf.name}…")
            ok, msg = rag.add_document(uf.name, uf.read(), progress_cb=bar)

            import time; time.sleep(0.3)
            bar.empty()

            st.session_state.processed_files[uf.name] = "ready" if ok else "error"
            if ok:
                st.success(f"✅ {uf.name} ready!")
            else:
                st.error(f"❌ {uf.name}: {msg}")

        st.rerun()

    # ── Document list ──────────────────────────────────────────────────────────
    if st.session_state.processed_files:
        st.markdown("### Indexed Documents")
        for fname, status in list(st.session_state.processed_files.items()):
            icon = "✅" if status == "ready" else "❌"
            short = fname[:24] + "…" if len(fname) > 24 else fname
            c1, c2 = st.columns([5, 1])
            c1.markdown(f"{icon} `{short}`")
            if c2.button("✕", key=f"rm_{fname}", help="Remove"):
                rag.remove_document(fname)
                del st.session_state.processed_files[fname]
                st.rerun()

        ready_count = sum(1 for s in st.session_state.processed_files.values() if s == "ready")
        st.caption(f"**{ready_count}** doc(s) · **{rag.total_chunks()}** chunks indexed")

    st.divider()
    col1, col2 = st.columns(2)
    if col1.button("🗑️ Clear Docs", use_container_width=True):
        rag.clear()
        st.session_state.processed_files = {}
        st.rerun()
    if col2.button("💬 Clear Chat", use_container_width=True):
        st.session_state.chat_history = []
        st.rerun()

# ── Main chat area ─────────────────────────────────────────────────────────────
st.markdown("## 📄 PDF Knowledge Base")
st.markdown("Upload PDFs in the sidebar, then ask questions below. Answers come **only** from your documents.")
st.divider()

ready_docs = [f for f, s in st.session_state.processed_files.items() if s == "ready"]

# Render previous messages
for msg in st.session_state.chat_history:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("sources"):
            badges = " ".join(
                f'<span class="source-tag">📄 {s}</span>' for s in msg["sources"]
            )
            st.markdown(f"**Sources:** {badges}", unsafe_allow_html=True)

# Guard: need API key + at least one doc
if not rag._api_key:
    st.info("🔑 Enter your **Gemini API key** in the sidebar to get started.")
elif not ready_docs:
    st.info("📂 Upload at least **one PDF** in the sidebar to start asking questions.")
else:
    question = st.chat_input("Ask a question about your documents…")
    if question:
        # User bubble
        st.session_state.chat_history.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)

        # Assistant bubble
        with st.chat_message("assistant"):
            with st.spinner("Searching your documents…"):
                answer, sources = rag.query(question)
            st.markdown(answer)
            if sources:
                badges = " ".join(
                    f'<span class="source-tag">📄 {s}</span>' for s in sources
                )
                st.markdown(f"**Sources:** {badges}", unsafe_allow_html=True)

        st.session_state.chat_history.append({
            "role": "assistant",
            "content": answer,
            "sources": sources,
        })
        st.rerun()